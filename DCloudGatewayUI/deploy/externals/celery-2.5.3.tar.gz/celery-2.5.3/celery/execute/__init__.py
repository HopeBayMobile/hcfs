from __future__ import absolute_import

from .. import current_app

send_task = current_app.send_task
