=================
 Getting Started
=================

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    introduction
    brokers/index
    first-steps-with-celery
    resources
