==========================================
 celery.abstract
==========================================

.. contents::
    :local:
.. currentmodule:: celery.abstract

.. automodule:: celery.abstract
    :members:
    :undoc-members:
