=====================================================
 celery.actors
=====================================================

.. contents::
    :local:
.. currentmodule:: celery.actors

.. automodule:: celery.actors
    :members:
    :undoc-members:
