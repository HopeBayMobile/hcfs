import os
import sys

here = os.path.dirname(__file__)
base = os.path.dirname(here)
sys.path.insert(0, base)

# We can only import this after we ajdust the paths
import pkg_resources

# Make absolutely sure we're testing *this* package, no
# some other installed package
pkg_resources.require('PasteDeploy')
