__version__ = "0.15.1"

# Void cython.* directives (for case insensitive operating systems).
from Cython.Shadow import *
